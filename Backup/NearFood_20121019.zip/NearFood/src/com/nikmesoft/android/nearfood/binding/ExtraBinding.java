package com.nikmesoft.android.nearfood.binding;

public class ExtraBinding {

}
