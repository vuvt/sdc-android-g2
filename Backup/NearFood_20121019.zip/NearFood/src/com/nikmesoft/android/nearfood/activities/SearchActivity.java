package com.nikmesoft.android.nearfood.activities;

import android.os.Bundle;

import com.nikmesoft.android.nearfood.R;

public class SearchActivity extends BaseActivity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_search);
	}
}
