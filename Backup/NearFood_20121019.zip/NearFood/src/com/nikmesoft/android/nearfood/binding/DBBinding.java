package com.nikmesoft.android.nearfood.binding;

public class DBBinding {
	public static final String DB_NAME = "NearFood";
}
