package com.nikmesoft.android.nearfood.activities;

import com.nikmesoft.android.nearfood.R;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

public class FavoritesActivity extends BaseActivity implements OnClickListener {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_favorites);
		init();
	}

	private void init() {

	}

	public void onClick(View v) {

	}
}
