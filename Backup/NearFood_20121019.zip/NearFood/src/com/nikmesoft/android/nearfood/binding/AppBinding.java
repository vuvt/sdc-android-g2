package com.nikmesoft.android.nearfood.binding;

public class AppBinding {
	public static String PACKAGE_NAME = "com.nikmesoft.android.nearfood";
}
