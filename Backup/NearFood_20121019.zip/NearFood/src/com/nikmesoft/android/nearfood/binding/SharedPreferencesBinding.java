package com.nikmesoft.android.nearfood.binding;

public class SharedPreferencesBinding {
	public static final String PREFS = AppBinding.PACKAGE_NAME + "_preferences";
	public static final String FIRSTUSE = "prefs_firstuse";
}
